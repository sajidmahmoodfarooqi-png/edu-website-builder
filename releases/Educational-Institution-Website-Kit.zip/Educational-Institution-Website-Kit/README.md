# Educational Institution Website — Starter Kit (v2.1)

This kit lets a school, college, university or academy set out everything its
website and portals need **once, upfront** — so the site can be built with
minimal back-and-forth, by an AI agent (Claude Code or Google Antigravity) or by
a web team.

---

## What's inside

| File / Folder | What it is |
| :--- | :--- |
| **`Needs-Assessment-Form.md`** / `.docx` / `.pdf` | The intake form: identity, branding, languages, pages, admissions, portal, mobile app, directorates (QEC, societies, sports, hostel), accessibility, roles, hosting, security and handover. |
| **`Module-Catalog.md`** | Every page and feature that can be built, what each needs, and how it is built. |
| **`Materials-Folder-Guide.md`** | Where to put logos, photos, staff lists, timetables and documents, and in what format. |
| **`scripts/scaffold_materials.py`** | Creates the labelled `website-materials/` folders (with instructions and CSV templates) for the features you chose. |
| **`scripts/render_form_docx.py`** | Regenerates the Word form from the Markdown form. |
| **`skills/edu-website-builder/`** | The AI skill: reads a filled form, plans the build, and builds the site with you. |

The ready-made module library (theme code) is being rebuilt as a brand-free,
switchable set of modules and will ship in a later release.

---

## How to use it

1. **Fill the Needs Assessment Form** (`.docx` is easiest). Leave anything you're
   unsure of blank.
2. **Create and fill the materials folders:**
   ```bash
   python scripts/scaffold_materials.py --root . --only departments,admissions,portal
   ```
   (`--all` creates every folder.) Name each person's photo exactly as their
   full name, and keep the CSV headers as given.
3. **Hand both to your AI agent** with the `edu-website-builder` skill installed
   and ask it to build the site from the filled form. It shows you a build plan
   first and asks before any deployment.

---

## Principles the builds follow

* Free and open-source; runs on ordinary shared hosting (PHP + MySQL).
* No tracking, no paid SMS/WhatsApp APIs, no default passwords or passcodes.
* Uploaded documents never publicly reachable; personal data kept private.
* Responsive and accessible, with optional bilingual / right-to-left content.

Released under the MIT License.
